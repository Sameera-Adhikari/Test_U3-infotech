namespace Minesweeper.Test
{
    public class MinesweeperTest
    {
        [Fact]
        public void WhenSteppedOnAMine_ThenReturnTrue()
        {            
            int[,] detailBoard = new int[3, 3];

            for (int i = 0; i < 3; i++)
            {
                detailBoard[i, 0] = -1;
                detailBoard[i, 1] = 0;
                detailBoard[i, 2] = -1;
            }

            Board bd = new();

            bd.detailBoard = detailBoard;

            for (int x = 0; x < 3; x++)
            {
                Assert.Equal(bd.IsMine(x, 0), true);
                Assert.Equal(bd.IsMine(x, 1), false);
                Assert.Equal(bd.IsMine(x, 2), true);

            }
        }

        [Fact]
        public void WhenVisitedSquare_ThenReturnTrue_ElseReturnFalse()
        {
            bool[,] visited = new bool[3, 3];

            for (int i = 0; i < 3; i++)
            {
                visited[i, 0] = false;
                visited[i, 1] = true;
                visited[i, 2] = false;
            }

            Board bd = new();

            bd.visited = visited;

            for (int x = 0; x < 3; x++)
            {
                Assert.Equal(bd.IsValidMove(x, 0), true);
                Assert.Equal(bd.IsValidMove(x, 1), false);
                Assert.Equal(bd.IsValidMove(x, 2), true);
            }

        }

        [Fact]
        public void WhenNonVisitedSquareEqualMines_ThenReturnTrue_ElseReturnFalse()
        {
            bool[,] visited = new bool[3, 3];
            int mines = 2;

            for (int i = 0; i < 3; i++)
            {
                visited[i, 0] = true;
                visited[i, 1] = true;
                visited[i, 2] = true;
            }

            visited[0, 0] = false;
            visited[1, 0] = false;

            Board bd = new();

            bd.visited = visited;
            bd.mines = mines;
            bd.size = 3;
            
            //win
            Assert.Equal(bd.IsWin(), true);

            visited[2, 0] = false;

            //not win
            Assert.Equal(bd.IsWin(), false);

        }

        [Fact]
        public void WhenSteppedOnMine_ThenReturnGameOverTrue()
        {
            int[,] detailBoard = new int[3, 3];
            char[,] gameBoard = new char[3, 3];
            bool[,] visited = new bool[3, 3];

            for (int i = 0; i < 3; i++)
            {
                detailBoard[i, 0] = -1;
                detailBoard[i, 1] = 0;
                detailBoard[i, 2] = -1;
                visited[i, 0] = false;
                visited[i, 1] = false;
                visited[i, 2] = false;
            }

            Board bd = new();

            bd.detailBoard = detailBoard;
            bd.visited = visited;
            bd.gameBoard = gameBoard;
            bd.gameOver = false;
            bd.size = 3;

            for (int x = 0; x < 3; x++)
            {
                bd.UncoverSquare(x, 0);
                visited[x, 0] = false;
                Assert.Equal(bd.gameOver, true);

                bd.gameOver = false;
                visited[x, 1] = false;
                bd.UncoverSquare(x, 1);
                Assert.Equal(bd.gameOver, false);

                bd.gameOver = false;
                visited[x, 2] = false;
                bd.UncoverSquare(x, 2);
                Assert.Equal(bd.gameOver, true);
            }
        }

        [Fact]
        public void WhenFourMinesAround_ThenReturnFour()
        {
            int[,] detailBoard = new int[3, 3];            

            for (int i = 0; i < 3; i++)
            {
                detailBoard[i, 0] = -1;
                detailBoard[i, 1] = 0;
                detailBoard[i, 2] = -1;                
            }

            Board bd = new();

            bd.detailBoard = detailBoard;  
            bd.size = 3;

            Assert.Equal(bd.CalculateMinesForSquare(0,1), 4);
        }

        [Fact]
        public void WhenNoMinesAround_ThenReturnZero()
        {
            int[,] detailBoard = new int[3, 3];

            for (int i = 0; i < 3; i++)
            {
                detailBoard[i, 0] = -1;
                detailBoard[i, 1] = 0;
                detailBoard[i, 2] = -0;
            }

            Board bd = new();

            bd.detailBoard = detailBoard;
            bd.size = 3;

            Assert.Equal(bd.CalculateMinesForSquare(0, 2), 0);
        }
    }
}