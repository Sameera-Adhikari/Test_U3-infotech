﻿using Microsoft.Extensions.DependencyInjection;

namespace Minesweeper.Core.ServiceContracts;

public interface IMinesweeperPrintService
{ 
    void PrintBoard<T>(int size, T[,] board);
    void PrintFinal(int size, int[,] detailBoard);

}
