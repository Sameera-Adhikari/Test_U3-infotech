﻿

namespace Minesweeper.Core.ServiceContracts
{
    public interface IBoardService
    {
        void InitializeBoard(ref int[,] board, ref char[,] gameBoard, ref bool[,] visited, int size);
    }
}
