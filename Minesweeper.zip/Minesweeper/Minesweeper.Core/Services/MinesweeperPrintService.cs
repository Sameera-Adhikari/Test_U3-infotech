﻿using Minesweeper.Core.ServiceContracts;

namespace Minesweeper.Core.Services
{
    public class MinesweeperPrintService : IMinesweeperPrintService
    {
        public void PrintBoard<T>(int size, T[,] board)
        {
            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    Console.Write("{0} ", board[i, j]);
                }
                Console.WriteLine();
            }
            Console.WriteLine();
        }

        public void PrintFinal(int size, int[,] detailBoard)
        {
            Console.WriteLine();
            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    if (detailBoard[i, j] == -1) Console.Write("X ");
                    else Console.Write("{0} ", 48 + detailBoard[i, j] - '0');
                }
                Console.WriteLine();
            }
        }

    }
}
