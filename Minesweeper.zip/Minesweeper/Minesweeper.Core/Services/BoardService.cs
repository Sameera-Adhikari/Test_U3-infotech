﻿using Minesweeper.Core.ServiceContracts;
using System.ComponentModel;
using System.Drawing;

namespace Minesweeper.Core.Services
{
    public class BoardService : IBoardService
    {
        public void InitializeBoard(ref int[,] board,ref char[,] gameBoard, ref bool[,] visited, int size)
        {
            board = new int[size, size];
            gameBoard = new char[size, size];
            visited = new bool[size, size];
        }
    }
}
