﻿using System;
using Microsoft.Extensions.DependencyInjection;
using Minesweeper.Core.ServiceContracts;
using Minesweeper.Core.Services;

namespace Minesweeper
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Welcome to Minesweeper!");
            Console.WriteLine();

            var services = CreateServices();

            MinesweeperGame minesweeper = new MinesweeperGame(services.GetService<IBoardService>(), services.GetService<IMinesweeperPrintService>());
            minesweeper.StartGame();
        }

        private static ServiceProvider CreateServices()
        {
            var serviceProvider = new ServiceCollection()
                    .AddSingleton<IMinesweeperPrintService, MinesweeperPrintService>()
                    .AddSingleton<IBoardService, BoardService>()
                    .BuildServiceProvider();
            return serviceProvider;
        }
    }
}