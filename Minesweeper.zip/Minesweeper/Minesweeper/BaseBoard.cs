﻿namespace Minesweeper
{
    public abstract class BaseBoard
    {
        public abstract void CreateInitialGrid();
        public abstract void GenerateBoard(int firstX, int firstY);
        public abstract void UncoverSquare(int x, int y);
        public abstract int CalculateMinesForSquare(int i, int j);
        public abstract bool IsMine(int x, int y);
        public abstract bool IsValidMove(int x, int y);
        public abstract bool IsWin();
        public abstract void Move(out int x, out int y);
    }
}
