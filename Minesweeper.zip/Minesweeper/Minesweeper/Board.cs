﻿using Minesweeper.Core.ServiceContracts;

namespace Minesweeper
{
    public class Board : BaseBoard
    {
        private readonly IBoardService _boardService;
        private readonly IMinesweeperPrintService _minesweeperPrintService;


        public int[,] detailBoard;
        //DetailBoard represents the board

        public char[,] gameBoard;
        //GameBoard used initially and has the details of the placement of mines        

        //sizexsize, i.e. matrix
        //board[,] =  -1 - for mine. value 0 to 8 gives total number of mines surrounding
        // 0 for no mines around
        public int size;

        // Shows the number of mines in the game
        public int mines;

        //Shows the visited fields
        public bool[,] visited;
        public bool gameOver;

        public Board(IBoardService boardService, IMinesweeperPrintService minesweeperPrintService)
        {
            _boardService = boardService;
            _minesweeperPrintService = minesweeperPrintService;
        }

        public Board()
        {
        }

        public override void CreateInitialGrid()
        {
            do
            {
                Console.WriteLine("\nEnter the size of the grid (e.g. 4 for a 4x4 grid, max 16):");
                while (!int.TryParse(Console.ReadLine(), out size))
{
                    Console.Clear();
                    Console.WriteLine("You entered an invalid number");
                    Console.Write("enter number of conversations ");
                }
                Console.WriteLine();
            } while (size < 0 || size > 16);

            do
            {
                Console.WriteLine("\nEnter the number of mines to place on the grid (maximum is 35% of the total squares): ");
                while (!int.TryParse(Console.ReadLine(), out mines))
                {
                    Console.Clear();
                    Console.WriteLine("You entered an invalid number");
                    Console.Write("enter number of conversations ");
                }
                Console.WriteLine();
            } while (mines < 0 || mines/(size*size) > 0.35);

            _boardService.InitializeBoard(ref detailBoard, ref gameBoard, ref visited, size);

            gameOver = false;

            //Fills the board with 0
            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    detailBoard[i, j] = 0;
                    gameBoard[i, j] = '_';
                    visited[i, j] = false;
                }
            }
        }

        //Randomly place the mines, calculates adjacent mine count
        public override void GenerateBoard(int firstX, int firstY)
        {
            Random generator = new Random();

            int placedMines = 0;

            while (placedMines < mines)
            {
                int mineI = 0, mineJ = 0;
                do
                {
                    mineI = (int)generator.Next(0, size); 
                    mineJ = (int)generator.Next(0, size);

                } while ((mineI == firstX && mineJ == firstY) || (detailBoard[mineI, mineJ] != 0));

                detailBoard[mineI, mineJ] = -1;
                placedMines++;
            }

            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    detailBoard[i, j] = CalculateMinesForSquare(i, j);
                }
            }
            UncoverSquare(firstX, firstY);

        }

        //Uncovers the given field and all nearby "empty" fields
        public override void UncoverSquare(int x, int y)
        {
            if (x >= 0 && x < size && y >= 0 && y < size) 
            {
                if (visited[x, y]) return; 

                //If hits a mine, game over
                if (IsMine(x, y))
                {
                    gameBoard[x, y] = 'X';
                    visited[x, y] = true;
                    gameOver = true;

                    return;
                }
                else
                {
                    if (detailBoard[x, y] > 0) 
                    {
                        visited[x, y] = true;
                        gameBoard[x, y] = (char)('0' + detailBoard[x, y]);
                    }
                    else 
                    {
                        visited[x, y] = true;
                        gameBoard[x, y] = '0';

                        //The program will check if the neighboring squars have been visited
                        //if a square has not been visited, then it will recursively call this function for that squar
                        if ((x + 1 < size) && !visited[x + 1, y]) UncoverSquare(x + 1, y);
                        if ((x + 1 < size && y + 1 < size) && !visited[x + 1, y + 1]) UncoverSquare(x + 1, y + 1);
                        if ((x + 1 < size && y - 1 >= 0) && !visited[x + 1, y - 1]) UncoverSquare(x + 1, y - 1);
                        if ((y + 1 < size) && !visited[x, y + 1]) UncoverSquare(x, y + 1);
                        if ((y - 1 >= 0) && !visited[x, y - 1]) UncoverSquare(x, y - 1);
                        if ((x - 1 >= 0 && y + 1 < size) && !visited[x - 1, y + 1]) UncoverSquare(x - 1, y + 1);
                        if ((x - 1 >= 0 && y - 1 >= 0) && !visited[x - 1, y - 1]) UncoverSquare(x - 1, y - 1);
                        if ((x - 1 >= 0) && !visited[x - 1, y]) UncoverSquare(x - 1, y);
                        gameOver = false;
                    }
                }
            }
            else
            {
                Console.WriteLine("Not a valid position.");
                return;
            }
        }

        //Calculates the number of nearby mines for one square
        public override int CalculateMinesForSquare(int i, int j)
        {
            if (detailBoard[i, j] == -1) return -1;

            int m = 0;

            if (i - 1 >= 0 && detailBoard[i - 1, j] == -1) m++;
            if (i - 1 >= 0 && j - 1 >= 0 && detailBoard[i - 1, j - 1] == -1) m++;
            if (i - 1 >= 0 && j + 1 < size && detailBoard[i - 1, j + 1] == -1) m++;
            if (j - 1 >= 0 && detailBoard[i, j - 1] == -1) m++;
            if (j + 1 < size && detailBoard[i, j + 1] == -1) m++;
            if (i + 1 < size && j - 1 >= 0 && detailBoard[i + 1, j - 1] == -1) m++;
            if (i + 1 < size && detailBoard[i + 1, j] == -1) m++;
            if (i + 1 < size && j + 1 < size && detailBoard[i + 1, j + 1] == -1) m++;

            return m;
        }

        //Checks if this square has a mine
        public override bool IsMine(int x, int y)
        {
            return (detailBoard[x, y] == -1) ? true : false;
        }

        //Checks the move is valid - the selected square is covered
        public override bool IsValidMove(int x, int y)
        {
            return visited[x, y] == false;
        }

        //If all squares that have uncovered are not mines, payer wins
        public override bool IsWin()
        {
            int m = 0;

            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    if (!visited[i, j])
                        m++;

                }
            }
            return m == mines;
        }

        public void PrintGameBoard(int size, char[,] gameBoard)
        {
            _minesweeperPrintService.PrintBoard(size, gameBoard);

        }

        public void PrintBoard(int size, int[,] detailBoard)
        {
            _minesweeperPrintService.PrintBoard(size, detailBoard);

        }        

        public void PrintFinal(int size, int[,] detailBoard)
        {
            _minesweeperPrintService.PrintFinal(size, detailBoard);            
        }

        //Gets user input and validate
        public override void Move(out int x, out int y)
        {
            string input;

            Console.WriteLine("Select a square to reveal(e.g. x = 1, y = 1)\n");                        

            Console.WriteLine("\nEnter coordinate x: ");
            input = Console.ReadLine();
            x = int.Parse(input);

            while (x < 0 || x >= size)
            {
                Console.WriteLine("\nNumber has to be between 0 and {0}", size);
                Console.WriteLine("\nEnter coordinate x: ");
                input = Console.ReadLine();
                x = int.Parse(input);
            }
            x = int.Parse(input); ;


            Console.WriteLine("\nEnter coordinate y: ");
            input = Console.ReadLine();
            y = int.Parse(input);

            while (y < 0 || y >= size)
            {
                Console.WriteLine("\nNumber has to be between 0 and {0}", size);
                Console.WriteLine("\nEnter coordinate y: ");
                input = Console.ReadLine();
                y = int.Parse(input);
            }
            y = int.Parse(input);

            Console.WriteLine();
        }
    }
}
