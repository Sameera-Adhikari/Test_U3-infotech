﻿
using Minesweeper.Core.ServiceContracts;

namespace Minesweeper
{
    public class MinesweeperGame : Board
    {
        public MinesweeperGame(IBoardService boardService, IMinesweeperPrintService minesweeperPrintService) : base(boardService, minesweeperPrintService)
        {
            gameOver = false;
            CreateInitialGrid();
        }                    

        public void StartGame()
        {          

            Console.WriteLine("Here is your minefield\n");

            //Print the initial board on the console 
            PrintGameBoard(size, gameBoard);

            //The first move
            //User input coordinates
            int x, y;
            Move(out x, out y);
            GenerateBoard(x, y);
            
            while (!IsWin() && !gameOver)
            {
                do
                {
                    PrintGameBoard(size, gameBoard);

                    //Here we can use PrintBoard(size, detailBoard) method for debugging purposes;

                    Console.WriteLine("This square contains {0} adjacent mines./n", gameBoard[x,y]);
                    Move(out x, out y);

                } while (!IsValidMove(x, y));

                //The user makes a move
                UncoverSquare(x, y);
            }

            if (gameOver)
            {
                PrintFinal(size, detailBoard);
                Console.WriteLine("YOU STEPPED ON A MINE! GAME OVER!\n");
            }
            else
            {
                PrintGameBoard(size, gameBoard);
                Console.WriteLine();
                Console.WriteLine("Congratulations, you have won the game!\n");
            }

            Console.WriteLine("Press any key to play again...");
            Console.ReadKey();
        }
        
    }
}